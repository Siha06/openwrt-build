#!/bin/sh
php-cli /root/proxy.php start -d  2>&1 &
