<?php
// 设置错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 获取请求的文件名
$requestUri = $_SERVER['REQUEST_URI'];
$filename = basename($requestUri);

// 如果有具体的文件名请求
if (preg_match('/^\d{8}\./', $filename)) {
    $searchPattern = substr($filename, 0, 8);  // 获取前8位数字
} else {
    header("HTTP/1.0 404 Not Found");
    exit("File not found");
}

// 数据库配置
$config = [
    'host' => '192.168.8.10',
    'port' => 3306,
    'dbname' => 'eVideoKTV',
    'username' => 'admin',
    'password' => 'admin'
];

try {
    // 连接数据库
    $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['dbname']}";
    $pdo = new PDO($dsn, $config['username'], $config['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 准备SQL查询，使用文件名前8位
    $sql = "SELECT CONCAT('http://',c.IP1,':9166', b.pathname,a.filename) as down 
            FROM FY_SONGFILE AS a 
            LEFT JOIN FY_PATH AS b ON a.PathID=b.PathSerialNo 
            LEFT JOIN FY_SERVER AS c ON b.ServerID=c.ID 
            WHERE FileName LIKE '" . $searchPattern . "%'";

    // 执行查询
    $stmt = $pdo->query($sql);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        $url = $result['down'];
        
        // 对URL中的中文进行编码
        $urlParts = parse_url($url);
        $encodedPath = implode('/', array_map('rawurlencode', explode('/', $urlParts['path'])));
        $encodedUrl = $urlParts['scheme'] . '://' . $urlParts['host'] . ':' . $urlParts['port'] . $encodedPath;
        
        // 检查文件是否可访问
        $headers = @get_headers($encodedUrl, 1);
        if ($headers === false || strpos($headers[0], '200') === false) {
            header("HTTP/1.0 404 Not Found");
            exit("File not found or not accessible");
        }
        
        $fileSize = $headers['Content-Length'];
        
        // 设置响应头
        header('Content-Type: video/mp2t');  // .ts文件的MIME类型
        header('Content-Length: ' . $fileSize);
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Accept-Ranges: bytes');
        
        // 关闭输出缓冲
        if (ob_get_level()) ob_end_clean();
        
        // 读取并输出文件内容
        $handle = @fopen($encodedUrl, 'rb');
        if ($handle === false) {
            header("HTTP/1.0 500 Internal Server Error");
            exit("Error: Cannot open file");
        }
        
        // 每次读取1MB并输出
        while (!feof($handle)) {
            echo fread($handle, 1024 * 1024);
            flush();
        }
        
        fclose($handle);
        exit;
    } else {
        header("HTTP/1.0 404 Not Found");
        exit("File not found");
    }

} catch (Exception $e) {
    header("HTTP/1.0 500 Internal Server Error");
    exit("Error: " . $e->getMessage());
} 
