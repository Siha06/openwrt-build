<?php
ini_set('memory_limit', '1024M');
ini_set('default_charset', 'UTF-8');
mb_internal_encoding('UTF-8');
ini_set('open_basedir', '');
@ini_set('max_execution_time', 0);
@ini_set('max_input_time', 0);

require_once __DIR__ . '/vendor/autoload.php';
use Workerman\Worker;
use Workerman\Connection\TcpConnection;
use Workerman\Connection\AsyncTcpConnection;

// 核心配置
$config = [
    'replace_regex' => '/^https?:\/\/.*\.tgz$/',
    'redirect_to' => 'http://47.97.125.154:1020',
    'worker_count' => 4,  // 进程数（建议=CPU核心数）
    'max_concurrent' => 1000,  // 最大并发连接数
    // 本地缓存能力
    'save_domain_regex' => '/^https?:\/\/sbbs.ycvod.cn\/.*$/',
    'local_resolve_regex' => '/^https?:\/\/saas.ycvod.cn\/.*$/',
    'max_save_bytes' => 10485760
];

// 解析HTTP请求
function parseReq($data) {
    $pos = strpos($data, "\r\n\r\n");
    if ($pos === false) return false;
    
    $head = substr($data, 0, $pos);
    $lines = explode("\r\n", $head);
    $first = explode(' ', $lines[0] ?? '', 3);
    
    $headers = [];
    foreach (array_slice($lines, 1) as $line) {
        $hpos = strpos($line, ':');
        if ($hpos !== false) {
            $key = trim(substr($line, 0, $hpos));
            $headers[$key] = trim(substr($line, $hpos+1));
        }
    }
    
    // 禁用压缩避免乱码
    if (!isset($headers['Accept-Encoding'])) {
        $headers['Accept-Encoding'] = 'identity';
    }
    
    return [
        'method' => $first[0] ?? '',
        'url' => $first[1] ?? '',
        'headers' => $headers,
        'body' => substr($data, $pos+4)
    ];
}

// 简单日志
function writeLog($message) {
    $logFile = __DIR__ . '/proxy.log';
    $timestamp = date('Y-m-d H:i:s');
    @file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
}

// 目录工具
function createDirectory($path) {
    if (!is_dir($path)) {
        @mkdir($path, 0755, true);
    }
}

// 与单进程版一致的文件名编码
function encodeUrlPathForFile($path) {
    return str_replace(['/', '?', '&', '=', '+'], ['%2F', '%3F', '%26', '%3D', '%2B'], $path);
}

// 本地命中
function localResolve($domain, $method, $path) {
    global $config;
    if (empty($config['local_resolve_regex'])) return null;
    if (strpos($path, '?') !== false) return null; // 不处理带 query
    $testUrl = "http://{$domain}{$path}";
    if (!preg_match($config['local_resolve_regex'], $testUrl)) return null;
    $baseDir = $domain;
    $methodDir = strtolower($method);
    $fileName = encodeUrlPathForFile($path ?: '/');
    $fullPath = __DIR__ . "/{$baseDir}/{$methodDir}/{$fileName}";
    if (file_exists($fullPath)) {
        $content = @file_get_contents($fullPath);
        if ($content !== false) {
            writeLog("Local resolve hit: {$fullPath}");
            return $content;
        }
    }
    return null;
}

// 保存响应
function saveResponse($domain, $method, $path, $responseData) {
    global $config;
    if (empty($config['save_domain_regex'])) return;
    if (strpos($path, '?') !== false) return;
    $testUrl = "http://{$domain}{$path}";
    if (!preg_match($config['save_domain_regex'], $testUrl)) {
        writeLog("Skip save (regex not matched): {$testUrl}");
        return;
    }
    $baseDir = $domain;
    $methodDir = strtolower($method);
    $fileName = encodeUrlPathForFile($path ?: '/');
    $fullPath = __DIR__ . "/{$baseDir}/{$methodDir}/{$fileName}";
    createDirectory(dirname($fullPath));
    @file_put_contents($fullPath, $responseData, LOCK_EX);
    writeLog("Saved response to: {$fullPath} (" . number_format(strlen($responseData)) . " bytes)");
}

// 域名替换
function replaceUrl($url, $headers) {
    global $config;
    if (!preg_match('/^https?:\/\//', $url)) {
        $host = $headers['Host'] ?? '';
        $url = $host ? "http://{$host}{$url}" : $url;
    }
    
    if (!preg_match($config['replace_regex'], $url)) {
        // 未触发重写，确保 Host 与 URL 的 host 一致
        $hostOfUrl = parse_url($url, PHP_URL_HOST);
        if ($hostOfUrl) {
            $headers['Host'] = $hostOfUrl;
        }
        return ['url' => $url, 'headers' => $headers];
    }
    
    $parsed = parse_url($url);
    $newUrl = $config['redirect_to'] . ($parsed['path'] ?? '');
    if (!empty($parsed['query'])) $newUrl .= "?{$parsed['query']}";
    
    $headers['Host'] = parse_url($config['redirect_to'], PHP_URL_HOST);
    return ['url' => $newUrl, 'headers' => $headers];
}

// 创建Worker
$worker = new Worker('tcp://0.0.0.0:8880');
$worker->count = $config['worker_count'];
$worker->maxConnections = $config['max_concurrent'];
$worker->connectionTimeout = 999999999;
$worker->reusePort = true;

// 客户端连接处理
$worker->onConnect = function(TcpConnection $conn) {
    $conn->reqData = '';
    $conn->maxSendBufferSize = 1024 * 1024 * 100; // 100MB上限
};

// 核心转发逻辑（移除setOption方法）
$worker->onMessage = function(TcpConnection $cliConn, $data) {
    $cliConn->reqData .= $data;
    if (strpos($cliConn->reqData, "\r\n\r\n") === false) return;
    
    $req = parseReq($cliConn->reqData);
    if (!$req) { $cliConn->close(); return; }
    // 构建原始完整URL用于本地命中与保存
    $originalUrl = $req['url'];
    if (!preg_match('/^https?:\/\//', $originalUrl)) {
        $origHostHeader = $req['headers']['Host'] ?? '';
        $originalUrl = $origHostHeader ? "http://{$origHostHeader}{$originalUrl}" : $originalUrl;
    }
    $origParsed = parse_url($originalUrl);
    if (!$origParsed || empty($origParsed['host'])) { $cliConn->close(); return; }
    $origHost = $origParsed['host'];
    $origPath = $origParsed['path'] ?? '/';
    if (!empty($origParsed['query'])) $origPath .= "?{$origParsed['query']}";

    // 本地命中优先
    $local = localResolve($origHost, $req['method'], $origPath);
    if ($local !== null) {
        $cliConn->send($local, true);
        $cliConn->close();
        return;
    }
    
    $res = replaceUrl($req['url'], $req['headers']);
    $parsed = parse_url($res['url']);
    if (!$parsed || !isset($parsed['host'])) { $cliConn->close(); return; }
    
    $host = $parsed['host'];
    $port = $parsed['port'] ?? ($parsed['scheme'] === 'https' ? 443 : 80);
    $path = $parsed['path'] ?? '/';
    if (!empty($parsed['query'])) $path .= "?{$parsed['query']}";
    
    // 创建异步远程连接（移除setOption调用）
    $remoteConn = new AsyncTcpConnection("tcp://{$host}:{$port}");
    $remoteConn->timeout = 999999999;
    // 低版本Workerman不支持setOption，注释掉该行为
    // $remoteConn->setOption('tcp_nodelay', 1);
    
    // 发送请求到目标服务器
    $remoteConn->onConnect = function(TcpConnection $rConn) use ($req, $path, $res) {
        $head = "{$req['method']} {$path} HTTP/1.1\r\n";
        foreach ($res['headers'] as $k => $v) {
            if (strtolower($k) !== 'connection') {
                $head .= "{$k}: {$v}\r\n";
            }
        }
        $head .= "Connection: close\r\n\r\n{$req['body']}";
        $rConn->send($head);
    };
    
    // 转发响应（原始字节传输）
    $headerSent = false;
    $shouldSave = (bool)preg_match($GLOBALS['config']['save_domain_regex'], $originalUrl);
    $maxSave = $GLOBALS['config']['max_save_bytes'] ?? (10 * 1024 * 1024);
    $responseBuffer = '';
    $remoteConn->onMessage = function(TcpConnection $rConn, $data) use ($cliConn, $req, &$headerSent, &$responseBuffer, $shouldSave, $maxSave) {
        if (!$headerSent) {
            $pos = strpos($data, "\r\n\r\n");
            if ($pos !== false) {
                $header = substr($data, 0, $pos + 4);
                $cliConn->send($header, true);
                $body = substr($data, $pos + 4);
                if ($req['method'] !== 'HEAD' && $body) {
                    $cliConn->send($body, true);
                }
                $headerSent = true;
                if ($shouldSave && strlen($responseBuffer) < $maxSave) {
                    $responseBuffer .= $data;
                }
            } else {
                $cliConn->send($data, true);
                if ($shouldSave && strlen($responseBuffer) < $maxSave) {
                    $responseBuffer .= $data;
                }
            }
        } else {
            if ($req['method'] !== 'HEAD') {
                $cliConn->send($data, true);
            }
            if ($shouldSave && strlen($responseBuffer) < $maxSave) {
                $responseBuffer .= $data;
            }
        }
        unset($data);
    };
    
    // 连接清理
    $remoteConn->onClose = $remoteConn->onError = $remoteConn->onTimeout = function() use ($cliConn, $req, $origHost, $origPath, &$responseBuffer, $shouldSave) {
        if ($shouldSave && $responseBuffer !== '') {
            saveResponse($origHost, $req['method'], $origPath, $responseBuffer);
        }
        $cliConn->close();
    };
    
    $remoteConn->connect();
};

// 连接关闭时释放资源
$worker->onClose = function(TcpConnection $conn) {
    unset($conn->reqData);
};

Worker::runAll();
