#!/bin/sh
php-cli /root/php/proxy.php start -d  2>&1 &
